ERÇİN AI — GERÇEK YAPAY ZEKÂ BAĞLANTILI PROJE

ÖNEMLİ:
Bu proje gerçek yapay zekâya bağlanacak şekilde hazırlanmıştır. Çalışması için:
1) Node.js 20 veya üzeri kurulu bir bilgisayar/sunucu gerekir.
2) Bir OpenAI API anahtarı gerekir. API kullanımı ücretli olabilir; ChatGPT aboneliği API kredisi sağlamaz.
3) API anahtarını ASLA tarayıcıya, HTML dosyasına veya bu sohbete koymayın. Yalnızca sunucunun gizli Environment Variables bölümüne OPENAI_API_KEY adıyla ekleyin.
4) Hosting ortamında OPENAI_MODEL değişkenini hesabınızda kullanılabilen bir modele ayarlayın. Varsayılan model adı hesabınızda desteklenmiyorsa değiştirin.

Yerelde çalıştırma:
- Bu klasörde terminal açın.
- npm install
- .env.example dosyasını .env olarak kopyalayın ve API anahtarını .env içine girin.
- npm start
- Tarayıcıda http://localhost:3000 adresini açın.

Bu klasör kaynak koddur; tek başına iPhone'da dosyaya dokunarak gerçek AI sohbeti başlatmaz. İnternette çalışması için Node.js destekleyen bir hosting servisine dağıtılmalıdır.
